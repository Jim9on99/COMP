require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const morgan = require('morgan');
const bcrypt = require('bcrypt');
const path = require('path');

const app = express();

// MongoDB
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/taskflow')
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// Models
const User = require('./models/User');
const Task = require('./models/Task');

// Middleware
app.use(morgan('dev'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));
app.set('view engine', 'ejs');

app.use(session({
  secret: process.env.SESSION_SECRET || 'supersecret',
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({ mongoUrl: process.env.MONGO_URI || 'mongodb://localhost:27017/taskflow' }),
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

// Auth middleware
const requireLogin = (req, res, next) => {
  if (!req.session.userId) return res.redirect('/login');
  next();
};

// ==================== Auth Routes ====================
app.get('/login', (req, res) => res.render('login'));
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (user && await bcrypt.compare(password, user.password)) {
    req.session.userId = user._id;
    return res.redirect('/tasks');
  }
  res.render('login', { error: 'Invalid credentials' });
});

app.get('/register', (req, res) => res.render('register'));
app.post('/register', async (req, res) => {
  const hashed = await bcrypt.hash(req.body.password, 10);
  await User.create({ username: req.body.username, password: hashed });
  res.redirect('/login');
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// ==================== Web CRUD (protected) ====================
app.get('/tasks', requireLogin, async (req, res) => {
  let query = Task.find({ userId: req.session.userId });

  if (req.query.title) query = query.where('title').regex(new RegExp(req.query.title, 'i'));
  if (req.query.status) query = query.where('status').equals(req.query.status);
  if (req.query.priority) query = query.where('priority').equals(req.query.priority);

  const tasks = await query.sort('-createdAt');
  res.render('index', { tasks, query: req.query });
});

app.get('/tasks/create', requireLogin, (req, res) => res.render('create'));
app.post('/tasks', requireLogin, async (req, res) => {
  await Task.create({ ...req.body, userId: req.session.userId });
  res.redirect('/tasks');
});

app.get('/tasks/edit/:id', requireLogin, async (req, res) => {
  const task = await Task.findOne({ _id: req.params.id, userId: req.session.userId });
  if (!task) return res.redirect('/tasks');
  res.render('edit', { task });
});

app.post('/tasks/update/:id', requireLogin, async (req, res) => {
  await Task.findByIdAndUpdate(req.params.id, req.body);
  res.redirect('/tasks');
});

app.post('/tasks/delete/:id', requireLogin, async (req, res) => {
  await Task.findByIdAndDelete(req.params.id);
  res.redirect('/tasks');
});

// ==================== RESTful API (no auth) ====================
app.get('/api/tasks', async (req, res) => res.json(await Task.find()));
app.post('/api/tasks', async (req, res) => {
  const task = await Task.create(req.body);
  res.status(201).json(task);
});
app.put('/api/tasks/:id', async (req, res) => {
  const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true });
  task ? res.json(task) : res.status(404).json({ error: 'Not found' });
});
app.delete('/api/tasks/:id', async (req, res) => {
  await Task.findByIdAndDelete(req.params.id);
  res.status(204).send();
});

// Start
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));